<?php
session_start();
$con = mysqli_connect('localhost','root','');
mysqli_select_db($con, 'artsy');
$Name = $_POST['name'];
$Password = $_POST['password'];
$Mail = $_POST['mail'];
$Phone = $_POST['phone'];
$s = " select * from signup where name = '$Name'";
$result = mysqli_query($con, $s);
$num = mysqli_num_rows($result);
if($num == 1){
 header('location:Ssiginup.html');
 print "username exsists";
}else{
 $reg= "insert into signup(Name , Password , Mail , Phone) values ('$Name' , '$Password' , '$Mail' , '$Phone')";
 mysqli_query($con, $reg);
header('location:Slogin.php');
}
?>