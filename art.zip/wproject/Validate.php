<?php
session_start();

$con = mysqli_connect('localhost','root','');
mysqli_select_db($con, 'artsy');
$Name = $_POST['name'];
$Password = $_POST['password'];

$s = " select * from signup where name = '{$Name}' and password = '{$Password}'";
$result = mysqli_query($con, $s);

if(mysqli_num_rows($s)>0){
      header('location:aboutus.html');
}else{
      header('location:Slogin.html');

}
?>