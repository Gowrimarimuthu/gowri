<?php
include 'config.php';
if(isset($_POST['submit']))
{
	$Name = $_POST['name'];
	$Password = $_POST['pass'];
	$q = mysqli_query($con,"select * from signup where Name = '{$Name}' and password = '{$Password}'");
if(mysqli_num_rows($q) >0)
	{
 header('location:2.html');

}
else
{
	 header('location:Slogin.php');
      echo "invalid credientials"

}
}
?>
<html>
<head>
<style>
body, html {
  height: 100%;
  font-family: Arial, Helvetica, sans-serif;
}

* {
  box-sizing: border-box;
}
.bg-img {
  
  background-image: url("bg3.jpg");
   height: 660px;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  position: relative;
}

.btn { 
background-color:transperent; 
border: none; 
color: black; 
padding: 12px 20px; 
cursor: pointer; 
width:43%;

text-decoration: none; 

border-radius: 15px; 
} 


.btn:hover {
  opacity: 1;
}
.container {
  position:absolute;

 
  border-width:5px;
  left:480px;
  bottom:250px;
  margin: 20px;
  max-width: 300px;
  padding: 16px;
  background-color: white;
  border-radius:25px;
}
p
{
color:cyan;
font-size:18px;
}
table{
color:cyan;
font-size:22px;
}
h1{
color:Red;
font-size:40px;
}

</style>
</head>
<body>
<div class="bg-img">
<form method="POST" class="container">
<center>
<h1>LOGIN PAGE</h1>
name <input type="text" name="name"><br><br>
password <input type="password" name="pass"><br><br>
<input type="submit"  name="submit" value="submit">

 <p> <b>new user</b> <input type="button" class="btn" onclick="window.location.href='Ssiginup.html';" value="create account"></p>

</center>
</form>
</div>
</body>
</html>
