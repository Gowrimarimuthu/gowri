<?php
session_start();
$msg = ""; 
$con = mysqli_connect('localhost','root','');
mysqli_select_db($con, 'artsy');
$Fname= $_POST['name1'];
$Lname= $_POST['name2'];
$Name = $_POST['name'];
$Password = $_POST['password'];
$Rpassword = $_POST['password1'];
$Mail = $_POST['mail'];
$Phone = $_POST['phone'];
$s = " select * from bsiginup where name = '$Name' ";
$result = mysqli_query($con, $s);
$num = mysqli_num_rows($result);
if($num == true){
$msg = "user exsists";
header('location:Bsiginup.html');
}
else{
 $reg= "insert into bsiginup(Fname , Lname , Name , Password , Rpassword , Mail , Phone) values ('$Fname' , '$Lname' , '$Name' , '$Password' , '$Rpassword' , '$Mail' , '$Phone')";
 mysqli_query($con, $reg);
$msg = "registerd successfully";
 header('location:Blogin.php');
}
?>