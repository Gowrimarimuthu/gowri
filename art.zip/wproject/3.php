﻿<!DOCTYPE html>
<html lang="en">
<head>

</head>
<div id="team" class="text-center">
  <div class="overlay">
    
      <div class="col-md-10 col-md-offset-1 section-title">
        <h2>Buyers</h2>
        <hr>
      </div>

	<?php 
		$conn=mysqli_connect("localhost","root","","artsy");
		$result=mysqli_query($conn,"SELECT * FROM seller");
		while($row=mysqli_fetch_assoc($result)){
     echo"<tr>";
	echo "<td>";
	echo'<img align=center  id="chatimg" src="data:image/jpeg;base64,'. base64_encode($row["Image"]) .'"/>';
	echo "</td>";
	echo"</tr>";
         echo"<tr>";
        echo"<td> contact details</td>";
	echo"<td>".$row['Text']. "</td>";
	echo"</tr>";


   
}
?>
</body>
</html>
<