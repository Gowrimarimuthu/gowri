<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		div{
			border-radius: 20px;
			background-image:url(n1.jpg);
			padding: 50px;
			margin: 75px;
			margin-left: 270px;
			font-size: 20px;
			width: 50%;
			font-family: sans-serif;	
				}
			td{
				padding: 10px;
				padding-left: 40px;
				text-align: center;
			}

		
		.button {
    font-family: Arial, Helvetica, sans-serif;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 21px;
    float:right;
    cursor: pointer;
}
.button:hover {
      background-color: #008CBA;
      color: black;
 }
.button:active {
  background-color: black;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}
#chatimg{
        	height: 300px;
        	width: 300px;
                float:auto;
        }
p{ 
color:crimson;
font-size: 60px; 
font-weight: 20px; 

} 	
body
{
 
  background-image: url("bg5.jpg");
  height:4650px;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  position: relative;	
}
	</style>

	
</head>
<body >
    <center>
     <p>Best Arts And Crafts</p>
</center>
	<a href="home.html" class="button"><b>Logout</b></a>

	
	<div id="chat"><center>
	<table border=1 bordercolor=red>
		<?php 
		$conn=mysqli_connect("localhost","root","","artsy");
		$result=mysqli_query($conn,"SELECT * FROM seller");
		while($row=mysqli_fetch_assoc($result))
{
		
	echo"<tr>";
	echo "<td>";
	echo'<img align=center  id="chatimg" src="data:image/jpeg;base64,'. base64_encode($row["Image"]) .'"/>';
	echo "</td>";
        echo"<td>".$row['Text']. "</td>";
	echo"</tr>";
         


}
?>
</table>
</center>
</div>
</body>
</html>