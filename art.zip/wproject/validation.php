<?php
$conn=mysqli_connect("localhost","root","","artsy");
session_start(); 

$Mail = ($_POST['mail']);
$Password = ($_POST['password']);

$result=mysqli_query($conn,"SELECT * FROM bsiginup WHERE mail='$Mail' and password='$Password'");


while(mysqli_fetch_array($result,MYSQLI_ASSOC)){
	
	header('location:aboutus.html');
	
}if(!mysqli_fetch_array($result,MYSQLI_ASSOC)){
	
	echo "Invalid Username or Password";
	
}

?>